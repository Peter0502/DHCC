/*************************************************
*2101��֤����ݲ�ѯ
* �� �� ��: spEB07.c
* ��������������֤�����ͺ�֤�������ѯ���˿ͻ�������Ϣ
* ��    ��: ���������
* ������ڣ�2010��10��23��
* �޸ļ�¼��
*     1. ��    ��:
*        �� �� ��:
*        �޸�����:
*************************************************/
#define  ERR_DEAL   { WRITEMSG  goto ErrExit;}
#include "string.h"
#define EXTERN
#include "public.h"
#include "cif_basic_inf_c.h"
#include "cif_id_code_rel_c.h"
#include "cif_per_inf_c.h"
#include "cif_addr_inf_c.h"
#include "cif_email_inf_c.h"

int spEB07()
{
        /** ���ݳ�ʼ�� **/
        struct cif_id_code_rel_c cif_id_code_rel;
        struct cif_basic_inf_c cif_basic_inf;
        struct cif_per_inf_c cif_per_inf;
        struct cif_addr_inf_c cif_addr_inf;
        struct cif_email_inf_c cif_email_inf;
        char   cOutBuf[21];
        int    ret = 0;
        char  Name[60+1];

				memset(Name,0x00, sizeof(Name));
        memset(&cif_id_code_rel, 0x00, sizeof(struct cif_id_code_rel_c));
        memset(&cif_basic_inf, 0x00, sizeof(struct cif_basic_inf_c));
        memset(&cif_per_inf, 0x00, sizeof(struct cif_per_inf_c));
        memset(&cif_addr_inf, 0x00, sizeof(struct cif_addr_inf_c));
        memset(&cif_email_inf, 0x00, sizeof(struct cif_email_inf_c));
        memset(cOutBuf,0x00,sizeof(cOutBuf));

        /** ȡֵ����ֵ **/
        get_zd_data("0250", Name);   /* �ͻ����� */
        get_zd_data("0680", cif_id_code_rel.id_type);   /* ֤������ */
        get_zd_data("0630", cif_id_code_rel.id_no);     /* ֤������ */
        vtcp_log("[%s].........[%s]", cif_id_code_rel.id_type, cif_id_code_rel.id_no);

        /* ����֤�����ͺ�֤������ȡ�ͻ��� */
       ret = Cif_id_code_rel_Sel(g_pub_tx.reply, &cif_id_code_rel,
                   "id_type = '%s' and id_no = '%s'", cif_id_code_rel.id_type, \
                                  cif_id_code_rel.id_no);
        if (ret == 100) 
        {
                if (cif_id_code_rel.id_type[0] == '1')
                {
                	
                }
                sprintf(acErrMsg, "��֤����Ϣû�еǼ�,�뵽�ͻ����ĵǼ�[%s]", \
                        g_pub_tx.reply);
                WRITEMSG
                        strcpy(g_pub_tx.reply, "D104");
                goto ErrExit;
        } 
        else if (ret) 
        {
                sprintf(acErrMsg, "ȡ�ͻ�֤����Ϣ�쳣![%s]", g_pub_tx.reply);
                WRITEMSG
                        strcpy(g_pub_tx.reply, "D103");
                goto ErrExit;
        }
        /* ������� */
        set_zd_long("0280",cif_id_code_rel.cif_no );    /*�ͻ���*/
        /* ���ݿͻ��Ų�ѯ�ͻ����� */
        ret = Cif_basic_inf_Sel(g_pub_tx.reply, &cif_basic_inf,
                                " cif_no=%ld ", cif_id_code_rel.cif_no);
        if (ret == 100) 
        {
                sprintf(acErrMsg, "��֤����Ӧ�Ŀͻ��Ų�����[%s]", g_pub_tx.reply);
                WRITEMSG
                        strcpy(g_pub_tx.reply, "D104");
                goto ErrExit;
        } 
        else if (ret) 
        {
                sprintf(acErrMsg, "ȡ�ͻ�������Ϣ�쳣![%s]", g_pub_tx.reply);
                WRITEMSG
                        strcpy(g_pub_tx.reply, "D103");
                goto ErrExit;
        }
        /* ������� */
       
        if(strcmp(Name,cif_basic_inf.name)!= 0)
	      {
	       	sprintf(acErrMsg,"[%s],[%d]�ͻ���������!����name=[%s],����cif_basic_inf.name=[%s]",__FILE__,__LINE__,Name,cif_basic_inf.name);
		  		WRITEMSG
		  		strcpy(g_pub_tx.reply,"D249");
		 			goto ErrExit;
	      }
	      
	       sprintf(acErrMsg,"[%s],[%d]Name=[%s],�˻��ͻ���=[%s],",__FILE__,__LINE__,Name,cif_basic_inf.name);
       WRITEMSG
        pub_base_strpack(cif_basic_inf.name);	
        set_zd_data("0250", cif_basic_inf.name);
        
        /* ���ݿͻ��Ų�ѯ�ͻ��Ա�*/
        ret = Cif_per_inf_Sel(g_pub_tx.reply, &cif_per_inf,
                                " cif_no = %ld ", cif_id_code_rel.cif_no);
        if (ret != 100 && ret != 0)
        {
        	sprintf(acErrMsg, "ȡ�ͻ�֤����Ϣ�쳣![%s]", g_pub_tx.reply);
            	WRITEMSG
                   	strcpy(g_pub_tx.reply, "D103");
                goto ErrExit;
        }
        set_zd_data("0660", cif_per_inf.sex);
        
        /* ���ݿͻ��Ų�ѯ�ͻ���ַ����������*/
        ret = Cif_addr_inf_Sel(g_pub_tx.reply, &cif_addr_inf,
                                " cif_no = %ld and addr_type = '2'", cif_id_code_rel.cif_no);
        if (ret != 100 && ret != 0)
        {
        	sprintf(acErrMsg, "ȡ�ͻ�֤����Ϣ�쳣![%s]", g_pub_tx.reply);
            	WRITEMSG
                   	strcpy(g_pub_tx.reply, "D103");
                goto ErrExit;
        }                        
        set_zd_data("0260", cif_addr_inf.addr);
        set_zd_data("0640", cif_addr_inf.post_code);
        
        /* ���ݿͻ��Ų�ѯ�ͻ���ϵ�绰���ֻ����뼰����*/
        memset(&cif_email_inf, 0x00, sizeof(struct cif_email_inf_c));
        ret = Cif_email_inf_Sel(g_pub_tx.reply, &cif_email_inf,
                                " cif_no = %ld and addr_type = '1'", cif_id_code_rel.cif_no);
        if (ret != 100 && ret != 0)
        {
        	sprintf(acErrMsg, "ȡ�ͻ�֤����Ϣ�쳣![%s]", g_pub_tx.reply);
            	WRITEMSG
                   	strcpy(g_pub_tx.reply, "D103");
                goto ErrExit;
        }
        set_zd_data("0620", cif_email_inf.email);
        memset(&cif_email_inf, 0x00, sizeof(struct cif_email_inf_c));
        ret = Cif_email_inf_Sel(g_pub_tx.reply, &cif_email_inf,
                                " cif_no = %ld and addr_type = '5'", cif_id_code_rel.cif_no);
        if (ret != 100 && ret != 0)
        {
        	sprintf(acErrMsg, "ȡ�ͻ�֤����Ϣ�쳣![%s]", g_pub_tx.reply);
            	WRITEMSG
                   	strcpy(g_pub_tx.reply, "D103");
                goto ErrExit;
        }
        set_zd_data("0610", cif_email_inf.email);
        memset(&cif_email_inf, 0x00, sizeof(struct cif_email_inf_c));
	ret = Cif_email_inf_Sel(g_pub_tx.reply, &cif_email_inf,
                                " cif_no = %ld and addr_type = '6'", cif_id_code_rel.cif_no);
        if (ret != 100 && ret != 0) 
        {
        	sprintf(acErrMsg, "ȡ�ͻ�֤����Ϣ�쳣![%s]", g_pub_tx.reply);
            	WRITEMSG
                   	strcpy(g_pub_tx.reply, "D103");
                goto ErrExit;
        }
        set_zd_data("0810", cif_email_inf.email);

        /*
        sprintf(g_pub_tx.ac_no, "%ld", cif_id_code_rel.cif_no);
        set_zd_data("0300", g_pub_tx.ac_no);
        sprintf(g_pub_tx.ac_no, "%ld", cif_id_code_rel.cif_no);
        */

OkExit:
        strcpy(g_pub_tx.reply, "0000");
        sprintf(acErrMsg, "Before OK return: reply is[%s]", g_pub_tx.reply);
        WRITEMSG
                set_zd_data(DC_REPLY, g_pub_tx.reply);
        return 0;
ErrExit:
        sprintf(acErrMsg, "Before return: reply is[%s]", g_pub_tx.reply);
        WRITEMSG
                set_zd_data(DC_REPLY, g_pub_tx.reply);
        return 1;
}
