/*************************************************
* �� �� ��:  spW003.c
* ���������� �˻���ϸ��ѯ 
*
* ��    ��:  chengbo 
* ������ڣ� 2009��3��27�� 
*
* �޸ļ�¼�� 
* ��   ��:	2009��3��31�� 
* �� �� ��:	gujingyu
* �޸�����:
*************************************************/
#define ERR_DEAL if( ret ) {\
		sprintf( acErrMsg, "sql error" ); \
		WRITEMSG \
		goto ErrExit; \
		}
#define EXTERN
#include "public.h"
#include "dd_mst_hst_c.h"
#include "mdm_ac_rel_c.h"
#include "td_mst_hst_c.h"
#include "com_branch_c.h"
#include "mdm_unprt_hst_c.h"
#define  PAGE_CNT  10		/* ������ҳ��ѯ��ÿҳ������ */
extern char *get_env_info(char *infoname);
spW003()
{
	struct mdm_ac_rel_c sMdm_ac_rel;
	struct dd_mst_hst_c vdd_mst_hst;
	  struct td_mst_hst_c vtd_mst_hst;
	struct dd_mst_hst_c f_dd_mst_hst;
	struct dd_mst_hst_c f_dd_mst_hsta;
	struct com_branch_c sCom_branch;
	struct mdm_unprt_hst_c sMdm_unprt_hst;

	char            add_ind[3];
	char            ct_ind[5];
	char            ac_no3[25];
	char            f_note_type9[41];
	char            f_acno0[25];
	char            filename[100];
	char            pcfilename[100];
	char            wherelist[1024];	/**��ѯ����**/
	char            tmpstr[512];
	char            tmpmo[512];
	char			sPc_flag[2];   /* �Թ���˽��־ */
	char            fieldlist[1024];	/**Ҫ��ѯ���ֶ��б�**/
	char            tablelist[128];	/**Ҫ��ѯ�ı���**/
	char            titstr[1024];
	int             ttlnum = 0;	/**��ȡ��������**/
	int             i = 0;
	int             ret = 0,  dPage = 0;
	double          j_tx_amt = 0.00;
	double          d_tx_amt = 0.00;
	FILE           *fp;
	char            tmp_date[9];
	char            tmp_time[7];
	int             currnum = 0;
	long            qs_date;
	long            jz_date,dBeg_num = 0, dEnd_num = 0;
	char            bz[4];
	char            flag[3];
	char            td_mdm[5];  /***/
	char            tx_date[8+1];
	char            sw_traceno[10+1];
	char            cFtpfile[200];

	memset(add_ind, 0x00, sizeof(add_ind));
	memset(sPc_flag,0,sizeof(sPc_flag));
	memset(ct_ind, 0x00, sizeof(ct_ind));
	memset(ac_no3, 0x00, sizeof(ac_no3));
	memset(f_note_type9, 0x00, sizeof(f_note_type9));
	memset(f_acno0, 0x00, sizeof(f_acno0));
	memset(&vdd_mst_hst, 0x00, sizeof(vdd_mst_hst));
		memset(&vtd_mst_hst, 0x00, sizeof(vtd_mst_hst));
	memset(&f_dd_mst_hst, 0x00, sizeof(f_dd_mst_hst));
	memset(&f_dd_mst_hsta, 0x00, sizeof(f_dd_mst_hsta));
	memset(&sMdm_ac_rel, 0x00, sizeof(sMdm_ac_rel));
	memset(&sCom_branch, 0x00, sizeof(sCom_branch));
	memset(tmpstr, 0x00, sizeof(tmpstr));
	memset(filename, 0x00, sizeof(filename));
	memset(pcfilename, 0x00, sizeof(pcfilename));
	memset(tmpmo, 0x00, sizeof(tmpmo));
	memset(titstr, 0x00, sizeof(titstr));
	memset(tmp_date, 0x00, sizeof(tmp_date));
	memset(tmp_time, 0x00, sizeof(tmp_time));
	memset(&g_pub_tx, 0, sizeof(g_pub_tx));
	memset(wherelist, 0, sizeof(wherelist));
	memset(fieldlist, 0, sizeof(fieldlist));
	memset(tablelist, 0, sizeof(tablelist));
	memset(bz, 0, sizeof(bz));
	memset(td_mdm, 0, sizeof(td_mdm));
	memset(tx_date, 0, sizeof(tx_date));
	memset(sw_traceno, 0, sizeof(sw_traceno));
	memset(cFtpfile, 0, sizeof(cFtpfile));
	pub_base_sysinit();

	get_zd_data("0300", f_acno0);
	pub_base_old_acno(f_acno0);	/** �������˺�**/
	get_zd_long("0440", &qs_date);
	get_zd_long("0450", &jz_date);
	get_zd_long("0540", &dBeg_num);	/* ��ʼ������ */
	get_zd_long("0550", &dEnd_num);	/* Ҫȡ���������� */
	vtcp_log("[%s],[%d],dEnd_num=%d", __FILE__, __LINE__, dEnd_num);
	get_zd_data("0710", flag);	/* ��ѯ��־ */
	get_zd_data("0660",sPc_flag);
	vtcp_log("LINE %d FILE %s  flag[%.3s]", __LINE__, __FILE__, flag);
	get_zd_data("0050",tx_date);
	get_zd_data("0520",sw_traceno);

	vtcp_log("%d@%s dpage[%ld] begnum[%ld] endnum[%ld]", __LINE__, __FILE__, dPage, dBeg_num, dEnd_num);
	dEnd_num = dBeg_num + dEnd_num - 1;	/* ���������� */
	vtcp_log("[%s],[%d],dEnd_num=%d", __FILE__, __LINE__, dEnd_num);

	/**��ѯ**/
	pub_base_strpack(f_acno0);
	ret = Mdm_ac_rel_Sel(g_pub_tx.reply, &sMdm_ac_rel, "ac_no='%s'", f_acno0);
	ERR_DEAL

		ret = Dd_mst_hst_Dec_Sel(g_pub_tx.reply, "ac_id=%ld and tx_date>=%ld and tx_date<=%d order by tx_date desc,trace_no desc,trace_cnt desc,tx_time desc", sMdm_ac_rel.ac_id, qs_date, jz_date);
		ERR_DEAL

			ttlnum = 0;

		while (1) {
			ret = Dd_mst_hst_Fet_Sel(&vdd_mst_hst, g_pub_tx.reply);
			if (ret == 100)
				break;
			ERR_DEAL

				if (!ttlnum) {
				sprintf( filename,"1021netbank%s%s",tx_date,sw_traceno );
				sprintf( pcfilename,"%s/%s",getenv("FILDIR"),filename );
				/**pub_base_AllDwnFilName(filename);**/
				fp = fopen(pcfilename, "w");
				if (fp == NULL) {
					sprintf(acErrMsg, " open file [%s] error ", pcfilename);
					WRITEMSG
						strcpy(g_pub_tx.reply, "S047");
					vtcp_log("[%s],[%d]",__LINE__,__FILE__);
					goto ErrExit;
				}
				vtcp_log("[%s],[%d],����ȫ·���ļ���Ϊ[%s],�ļ���Ϊ[%s]", __FILE__, __LINE__, pcfilename,filename);
				/**fprintf(fp, "~@ָ����ˮ��|@��������|@��֧�����־|@�տ��˺�|@�տ����|@���׽��|@���|@��������|@ժҪ|@���׿������|@����ʱ��|@����Ա��|@����������|\n");**/
				/**fprintf(fp, "~@��������|@����ʱ��|@�������|@���׽��|@�˻����|@ժҪ|\n");**/
				fprintf(fp, "~@��������|@����ʱ��|@�������|@���׽��|@�˻����|@ժҪ|@ƾ֤����|@ƾ֤����|\n");
			}
			if (vdd_mst_hst.add_ind[0] == '0') {
				strcpy(add_ind, "1");  /**1��**/
				j_tx_amt = j_tx_amt + vdd_mst_hst.tx_amt;
			} else if (vdd_mst_hst.add_ind[0] == '1') {
				strcpy(add_ind, "0");  /**0��**/
				d_tx_amt = d_tx_amt + vdd_mst_hst.tx_amt;
			}
			sprintf(tmp_date, "%ld", vdd_mst_hst.tx_date);
			sprintf(tmp_time, "%d", vdd_mst_hst.tx_time);
			strcpy(bz, "CNY");
			ret = Com_branch_Sel(g_pub_tx.reply, &sCom_branch, "br_no='%s'", vdd_mst_hst.tx_br_no);
			if (100 != ret)
				ERR_DEAL
					ttlnum++;
			vtcp_log("[%s],[%d],%d,%d", __FILE__,__LINE__,dBeg_num,dEnd_num);
			if (ttlnum >= dBeg_num && ttlnum <= dEnd_num) {	/* �����������ļ�¼���� */
					/**fprintf(fp, "|%d|%d|%s|%d|%d|%17.2f|%17.2f|%s|%s|%d|%06d|%s|%d|\n", vdd_mst_hst.trace_no, vdd_mst_hst.tx_date, add_ind, 123456789, 123456789, vdd_mst_hst.tx_amt, vdd_mst_hst.bal, sCom_branch.br_no, vdd_mst_hst.brf, vdd_mst_hst.ac_seqn, vdd_mst_hst.tx_time, vdd_mst_hst.tel, 0);
	        vtcp_log("��ʼ��ӡ��|%d|%d|%s|%d|%d|%17.2f|%17.2f|%s|%s|%d|%d|%s|%d|\n", vdd_mst_hst.trace_no, vdd_mst_hst.tx_date, add_ind, 123456789, 123456789, vdd_mst_hst.tx_amt, vdd_mst_hst.bal, sCom_branch.br_no, vdd_mst_hst.brf, vdd_mst_hst.ac_seqn, vdd_mst_hst.tx_time, vdd_mst_hst.tel, 0);**/
	       /** fprintf(fp, "|%d|%06d|%s|%17.2f|%17.2f|%s|\n", vdd_mst_hst.tx_date, vdd_mst_hst.tx_time, add_ind, vdd_mst_hst.tx_amt, vdd_mst_hst.bal, vdd_mst_hst.brf);
	        vtcp_log("��ʼ��ӡ��|%d|%06d|%s|%17.2f|%17.2f|%s|\n", vdd_mst_hst.tx_date, vdd_mst_hst.tx_time, add_ind, vdd_mst_hst.tx_amt, vdd_mst_hst.bal, vdd_mst_hst.brf);**/
	        fprintf(fp, "|%d|%06d|%s|%17.2f|%17.2f|%32s|%30s|%8s|\n", vdd_mst_hst.tx_date, vdd_mst_hst.tx_time, add_ind, vdd_mst_hst.tx_amt, vdd_mst_hst.bal, vdd_mst_hst.brf, vdd_mst_hst.note_type, vdd_mst_hst.note_no);
	        vtcp_log("��ʼ��ӡ��|%d|%06d|%s|%17.2f|%17.2f|%s|%32s|%8s|\n", vdd_mst_hst.tx_date, vdd_mst_hst.tx_time, add_ind, vdd_mst_hst.tx_amt, vdd_mst_hst.bal, vdd_mst_hst.brf, vdd_mst_hst.note_type, vdd_mst_hst.note_no);
			}
		}


		ret = Dd_mst_hst_Clo_Sel();
		ERR_DEAL

			if (!ttlnum) {
			strcpy(g_pub_tx.reply, "S049");
			goto ErrExit;
		} else {
			fclose(fp);
			/**set_zd_data(DC_FILE_SND, "1");**/
			set_zd_int("0490", ttlnum);
			set_zd_double("0410",j_tx_amt);  /*��֧����*/
			set_zd_double("0420",d_tx_amt);  /*������*/
			set_zd_data("0260",filename);
			sprintf(cFtpfile,"%s/bin/ftp_to_nsw.sh %s %s %s",getenv("WORKDIR"),get_env_info("NSW_FTP_USER"),get_env_info("NSW_FTP_PWD"),filename);
			vtcp_log("%s,%d cFtpfile=[%s]\n",__FILE__,__LINE__,cFtpfile);
			ret=system(cFtpfile);
			if (ret)
			{
			sprintf(acErrMsg,"ftp�ļ�[%s]��ƽ̨����[%d]",filename,ret);
			WRITEMSG
			strcpy(g_pub_tx.reply,"P157");
			goto ErrExit;
			}
			sprintf(acErrMsg,"ftp�ļ�[%s]��ƽ̨�ɹ�",filename);
			WRITEMSG
			vtcp_log("[%s][%d],ttlnum=[%d],j_tx_amt=[%f],d_tx_amt=[%f],filename=[%s]", __FILE__, __LINE__, ttlnum,j_tx_amt,d_tx_amt,filename);
		}
	



GoodExit:
	strcpy(g_pub_tx.reply, "0000");
	sprintf(acErrMsg, "Before OK return: reply [%s]", g_pub_tx.reply);
	WRITEMSG
		set_zd_data(DC_REPLY, g_pub_tx.reply);
	return 0;
ErrExit:
	sprintf(acErrMsg, "Before bad return: reply [%s]", g_pub_tx.reply);
	WRITEMSG
		set_zd_data(DC_REPLY, g_pub_tx.reply);
	return 1;
}
