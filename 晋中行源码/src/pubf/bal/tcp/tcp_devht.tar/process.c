#include "bal.h"

int bal_process_tx(T_BTR*);

int bal_process_tx( T_BTR *bal_req )
{

#ifdef FOR_APCTL
	(*func)();
#endif

   return CSuccess;
}

