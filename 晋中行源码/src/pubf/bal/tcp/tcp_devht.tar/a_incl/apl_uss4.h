extern	struct apctl_work_area	 wk;
extern	struct apctl_split_area  split; 
extern	struct apctl_mg_global   mg_global;
extern	struct apctl_mg_date	 mg_date; 
