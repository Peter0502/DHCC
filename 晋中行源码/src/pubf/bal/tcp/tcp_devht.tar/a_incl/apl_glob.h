/******************************************************************/
/*    DECLARE  APCTL/TP  INTERFACE  AREA  AS  GLOBAL  STRUCTURE   */
/******************************************************************/
T_TITA_RECD            it_tita, *get_array;
T_TOTW_RECD            it_tota[TOTA_LIMIT], it_totw;
T_MACTA_RECD           it_macta[MACTA_LIMIT], it_mactw;
T_LOGW_RECD            it_loga[LOG_LIMIT], it_logw;
T_TXCOM_AREA           it_txcom;

