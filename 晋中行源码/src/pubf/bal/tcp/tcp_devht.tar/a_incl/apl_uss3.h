struct  apctl_work_area    wk;
struct  apctl_split_area   split;
struct  apctl_mg_global    mg_global;
struct  apctl_mg_date	   mg_date;
