/*	fname	fldid            */
/*	-----	-----            */
#define	SERVICE	((FLDID32)33555233)	/* number: 801	 type: long */
#define	INTERVAL	((FLDID32)33555234)	/* number: 802	 type: long */
#define	FLAGS	((FLDID32)33555235)	/* number: 803	 type: long */
