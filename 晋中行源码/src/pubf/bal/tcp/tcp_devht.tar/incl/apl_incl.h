/******************************************************************/
/*    DECLARE  APCTL/TP  INTERFACE  AREA  AS  EXTERN  STRUCTURE   */
/******************************************************************/
#include "apl_itf.h"
extern  T_TITA_RECD       it_tita, *get_array;
extern  T_TOTW_RECD       it_tota[TOTA_LIMIT], it_totw;
extern  T_MACTA_RECD      it_macta[MACTA_LIMIT], it_mactw;
extern  T_LOGW_RECD       it_loga[LOG_LIMIT], it_logw;
extern  T_TXCOM_AREA      it_txcom;
extern  char RTBIT[129];
extern  char RtCode[5];
/**
char ext_name[41];
double ext_avbal;
**/
