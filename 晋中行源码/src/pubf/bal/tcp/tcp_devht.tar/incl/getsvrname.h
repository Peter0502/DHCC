#define BRNO_LEN			5
#define TASKID_LEN			2
#define TASKNAME_LEN		14
#define REGION_LEN			7
#define SERVER_LEN			15
