#ifndef _APCTL_H
#define _APCTL_H

#ifndef _APCTL_ITF_H
#define _APCTL_ITF_H
#include "apl_itf.h"
#endif

#ifndef _APCTL_GLOBAL_H
#define _APCTL_GLOBAL_H
#include "apl_glob.h"
#endif

#ifndef _APCTL_USS1_H
#define _APCTL_USS1_H
#include "apl_uss1.h"
#endif

#endif
